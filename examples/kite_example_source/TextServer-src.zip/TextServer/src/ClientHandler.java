import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Date;
import java.util.concurrent.ArrayBlockingQueue;


public class ClientHandler implements Runnable {

	private Socket clientSocket;
	private ArrayBlockingQueue<String> queue;
	private int linesRate;
	private int maxRate;
	private int id;
	
	public ClientHandler(int clientId, Socket client, ArrayBlockingQueue<String> queue, int linesRate, int maxRate) {
		this.clientSocket = client;
		this.queue = queue;
		this.linesRate = linesRate;
		this.maxRate = maxRate;
		id = clientId;
	}
	@Override
	public void run() {
		handleClient();
	}
	private void handleClient() {
		
		try {
		    BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); 
		    PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
	
		    String inputLine; 
	
		    Date lastConnection = new Date();
		    long connections = 0;
		    
		    while ((inputLine = in.readLine()) != null) 
	        {
				if(inputLine.toLowerCase().compareTo("data")==0)
				{
					double duration_seconds = ((new Date().getTime() - lastConnection.getTime())*1.0/1000.0);
				    int batchSize = connections==0? linesRate: (int) duration_seconds*linesRate;
				    batchSize = Math.min(batchSize, maxRate);
				    batchSize = Math.max(batchSize, linesRate);
				    
				    lastConnection = new Date();
				    ++connections;
				    
				    //writing output to client
				    System.out.println("Sending "+batchSize+" lines... to client "+id);
				    out.println(""+batchSize);
				    for(int i = 0; i < batchSize; ++i)
				    {
				    	String line = queue.take();
				    	out.println(line);
				    }
				    
				    System.out.println("Data sent successfully to client "+id);
				}
				else if(inputLine.toLowerCase().compareTo("close")==0)
				{
					out.close();
					in.close();
					clientSocket.close();
				}
	        }
		} catch(IOException e){
			System.err.println(e.getMessage());
			System.out.println("Client "+id+ " is disconnedted");
		} catch (InterruptedException e) {
			System.err.println(e.getMessage());
			System.out.println("Client "+id+ "is disconnedted");
		} catch(Exception e) {
			System.err.println(e.getMessage());
			System.out.println("Client "+id+ "is disconnedted");
		}
	}

}
