import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.concurrent.ArrayBlockingQueue;


public class TextConsumer implements Runnable {

	private ArrayBlockingQueue<String> queue;
	private int port;
	private int linesRate;
	private int maxRate;
	private String TCP_or_UDP;

	public TextConsumer(ArrayBlockingQueue<String> queue, int port,
			int linesRate, int maxRate, String TCP_or_UDP) {
		this.queue = queue;
		this.port = port;
		this.linesRate = linesRate;
		this.maxRate = maxRate;
		this.TCP_or_UDP = TCP_or_UDP.toLowerCase();
	}

	@Override
	public void run() {
		if(TCP_or_UDP.compareTo("tcp")==0)
		{
			runTCPServer();
		}
	}

	private void runTCPServer() {
		ServerSocket serverSocket = null; 

	    try { 
	         serverSocket = new ServerSocket(port); 
	    } 
	    catch (IOException e) 
        { 
	    	System.err.println("Could not listen on port: "+port); 
        	System.exit(1); 
        } 

	  
	    int clients = 0;
	    while(true)
	    {
		    System.out.println ("Waiting for connection.....");
	
		    try { 
		    	Socket clientSocket = serverSocket.accept(); 
			    System.out.println ("Connection successful");
			    ++clients;
			    Thread clientThread = new Thread(new ClientHandler(clients, clientSocket, queue, linesRate, maxRate));
			    clientThread.start(); 
			} 
		    catch (IOException e) 
	        { 
	        	System.err.println("Skipping I/O exception. "+e.getMessage()); 
	        }
	    }
	     
	    //serverSocket.close();
	}

}
