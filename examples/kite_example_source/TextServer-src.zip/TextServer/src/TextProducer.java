import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;

import edu.umn.cs.kite.preprocessing.TweetJSONPreprocessor;
import edu.umn.cs.kite.util.microblogs.Tweet;


public class TextProducer implements Runnable {

	private ArrayBlockingQueue<String> queue;
	private String dataDirectory;
	private int bufferSize;
	private TextStream stream;
	
	public TextProducer(ArrayBlockingQueue<String> queue,
			String dataDirectory, int bufferSize) {
		this.queue = queue;
		this.dataDirectory = dataDirectory;
		this.bufferSize = bufferSize;
		this.stream = new TextStream(dataDirectory);
	}

	@Override
	public void run() {
		while(true)
		{
			readData();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void readData() {
		while(queue.size() < bufferSize)
		{
			int batchSize = Math.min(10000, bufferSize-queue.size());
			ArrayList<String> lines = stream.readNextLinesBatch(batchSize);
			ArrayList<String> preprocessed_lines = preprocessJSONTweets(lines);
			queue.addAll(preprocessed_lines);
		}
	}

	private ArrayList<String> preprocessJSONTweets(ArrayList<String> lines) {
		ArrayList<String> preprocessed_lines = new ArrayList<String>();
		TweetJSONPreprocessor preprocessor = new TweetJSONPreprocessor();
		List<Tweet> tweets = preprocessor.preprocess(lines);
		for(Tweet tw:tweets) {
			preprocessed_lines.add(tw.toString());
		}
		return preprocessed_lines;
	}
}
