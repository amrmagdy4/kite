import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.file.DirectoryIteratorException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.zip.GZIPInputStream;


public class TextStream {

	private ArrayList<String> folders = new ArrayList<String>();
	private int nextFolder = -1;
	private ArrayList<String> files = new ArrayList<String>();
	private int nextFile = -1;
	private BufferedReader stream = null;
	
	public TextStream(String dataDirectory) {
		File dir = new File(dataDirectory);
		if(dir.isDirectory())
		{
			File [] dir_files = dir.listFiles();
			Arrays.sort(dir_files);
			for(int i = 0; i < dir_files.length; ++i)
			{
				if(dir_files[i].isDirectory())
					folders.add(dir_files[i].getAbsolutePath());
				else if(dir_files[i].isFile())
					files.add(dir_files[i].getAbsolutePath());
			}
			if(files.size() > 0)
				nextFile = 0;
			if(folders.size() > 0)
			{
				nextFolder = 0;
				while(nextFile < 0)
				{
					expandNextFolder();
					if(files.size() > 0)
						nextFile = 0;
				}
			}
		}
	}

	private void expandNextFolder() {
		files.addAll(getFilePaths(folders.get(nextFolder)));
		incrementNextFolder();
	}

	private ArrayList<String> getFilePaths(String folder_path) {
		ArrayList<String> filePaths = new ArrayList<String>();
		File dir = new File(folder_path);
		File [] dir_files = dir.listFiles();
		Arrays.sort(dir_files);
		for(int i = 0; i < dir_files.length; ++i)
			filePaths.add(dir_files[i].getAbsolutePath());
		return filePaths;
	}

	private void incrementNextFolder() {
		nextFolder++;
		if(nextFolder >= folders.size())
			nextFolder = 0;
	}

	private void incrementNextFile() {
		++nextFile;
		if(nextFile >= files.size())
		{
			files.clear();
			nextFile = -1;
			while(nextFile < 0)
			{
				expandNextFolder();
				if(files.size() > 0)
					nextFile = 0;
			}
		}
	}
	
	public ArrayList<String> readNextLinesBatch(int batchSize) {
		if(stream == null)
			openNextFile();
		
		ArrayList<String> lines = new ArrayList<String>();
		for(int i = 0; i < batchSize; ++i)
		{
			String line = null;
			try {
				line = stream.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if(line != null)
				lines.add(line);
			else
				openNextFile();
		}
		return lines;
	}

	private void openNextFile() {
		try {
			InputStream fileStream = new FileInputStream(files.get(nextFile));
			InputStream gzipStream = new GZIPInputStream(fileStream);
			Reader decoder = new InputStreamReader(gzipStream, "US-ASCII");
			stream = new BufferedReader(decoder);
			incrementNextFile();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
