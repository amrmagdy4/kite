package edu.umn.cs.kite.util;

/**
 * Created by amr_000 on 8/1/2016.
 */
public interface GeoLocation {
}
